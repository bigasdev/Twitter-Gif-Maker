﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;

namespace EncoderProject
{
    partial class Form1
    {
        private const string V = " -c:v libx264 -b:v 2600k -pass 1 -an -f mp4 results/$2.mp4";
        private Quality quality = Quality.low;

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        
        private void InitializeComponent()
        {
            
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.MaximizeBox = false;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Text = "Mp4 to GIF";
            StartIconAndBackground();
        }
        private void CreateButton(object sender, EventArgs e){
            Button button = new Button();
            Image image = System.Drawing.Bitmap.FromFile("images/compressVideo.jpg");
            this.Controls.Add(button);
            button.Image = image;
            button.Location = new Point(170,80);
            button.Size = new Size(250,250);
            button.MouseClick += EncondeButton;

            Button low = new Button();
            Image lowImage = System.Drawing.Bitmap.FromFile("images/lowqualityGif.jpg");
            this.Controls.Add(low);
            //button.Text = "Compress video";
            low.Image = lowImage;
            low.Location = new Point(145,340);
            low.Size = new Size(100,25);
            low.MouseClick += LowQuality;
            low.MouseClick += GifConvertButton;

            Button med = new Button();
            Image medImage = System.Drawing.Bitmap.FromFile("images/medqualityGif.jpg");
            this.Controls.Add(med);
            //button.Text = "Compress video";
            med.Image = medImage;
            med.Location = new Point(245,340);
            med.Size = new Size(100,25);
            med.MouseClick += MedQuality;
            med.MouseClick += GifConvertButton;

            Button high = new Button();
            Image highImage = System.Drawing.Bitmap.FromFile("images/highqualityGif.jpg");
            this.Controls.Add(high);
            //button.Text = "Compress video";
            high.Image = highImage;
            high.Location = new Point(345,340);
            high.Size = new Size(100,25);
            high.MouseClick += HighQuality;
            high.MouseClick += GifConvertButton;
            
            void LowQuality(object sender, EventArgs e){
                quality = Quality.low;
            }
            void MedQuality(object sender, EventArgs e){
                quality = Quality.medium;
            }
            void HighQuality(object sender, EventArgs e){
                quality = Quality.high;
            }
        }
        private void StartIconAndBackground(){
            Image image = System.Drawing.Bitmap.FromFile("images/eggscapeHeader.jpg");
            Image backgroundImage = System.Drawing.Bitmap.FromFile("images/test.jpg");
            Bitmap bitmap = (System.Drawing.Bitmap)image;
            IntPtr icon = bitmap.GetHicon();
            Icon myIcon = System.Drawing.Icon.FromHandle(icon);
            BackgroundImage = backgroundImage;
            this.Icon = myIcon;
        }
        private void EncondeButton(object sender, EventArgs e){
            var fileContent = string.Empty;
            var filePath = string.Empty;

                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = "c:\\";
                    openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //Get the path of specified file
                        filePath = openFileDialog.FileName;

                        //Read the contents of the file into a stream
                        var fileStream = openFileDialog.OpenFile();

                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            fileContent = reader.ReadToEnd();
                        }
                    }
            }
            if(String.IsNullOrEmpty(filePath))return;
            string encodeText = "ffmpeg -y -i " + filePath + V;
            string newEncodeText = "ffmpeg -i " + "results/$2.mp4" + " -c:v libx264 -b:v 2600k -pass 2 -an results/$3.mp4";
            string first = "ECHO Compressing video please wait...\n";
            string second = "CALL " + encodeText + "\n";
            string third = "CALL " + newEncodeText +  "\n";
            string path = "bat/mp4bat.bat";
            using(StreamWriter writer = File.CreateText(path)){
                writer.WriteLine(first);
                writer.WriteLine(second);
                writer.WriteLine(third);
            }
            System.Diagnostics.Process ps = new System.Diagnostics.Process();
            ps.StartInfo.FileName = path;
            ps.Start();
            ps.Exited += ExitCheck;       
            void ExitCheck(object sender, EventArgs e){
                if(File.Exists("$2.mp4")){
                File.Delete("$2.mp4");
                }
            }
        }
        private void GifConvertButton(object sender, EventArgs e){
            var command = "";
            if(quality == Quality.high){
                command = " -w 800 -q 6 -o results/$2.gif";
            }else if(quality == Quality.medium){
                command = " -w 600 -o results/$2.gif";
            }else{
                command = " -w 450 -q 4 -o results/$2.gif";
            }
            var fileContent = string.Empty;
            var filePath = string.Empty;

                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = "c:\\";
                    openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //Get the path of specified file
                        filePath = openFileDialog.FileName;

                        //Read the contents of the file into a stream
                        var fileStream = openFileDialog.OpenFile();

                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            fileContent = reader.ReadToEnd();
                        }
                    }
            }
            if(String.IsNullOrEmpty(filePath))return;
            string content = "video2gif " + filePath + command;
            string strCmdText = "/K" + content;
            using(System.Diagnostics.Process cmd = System.Diagnostics.Process.Start("CMD.exe",strCmdText)){
                cmd.WaitForExit();
            }
        }

        #endregion
    }
    public enum Quality{
        low,
        medium,
        high
    }
}

